/**
 * 
 */

var app=angular.module("fileUploadDownloadApp",['angularFileUpload']);

app.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;
            
            element.bind('change', function(){
                scope.$apply(function(){
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

app.service('fileUpload', ['$http', function ($http) {
    this.uploadFileToUrl = function(file, uploadUrl){
        var fd = new FormData();
        fd.append('file', file);
        var response=$http.post(uploadUrl, fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        });
        return response;
    }
}]);

var uploadDownloadController=function($scope,$upload,$http,fileUpload){
    
    $scope.selectFile=function($files){
        console.log("file selected : ",$files);
        $scope.uploadedFile = [ {file : ''} ];
        if($files.length>0){
            $scope.uploadedFile[0].file=$files[0];
        }
    };
    $scope.upload=function(){
        console.log("upload function called");
        var fileName=$scope.uploadedFile[0].file.name;
        console.log("step 1:",fileName);
        
        /*$http.post('rest/uploadFiles', 
                {filename: $scope.uploadedFile[0].file.name,
                file:$scope.uploadedFile[0].file,
                fileSize:$scope.uploadedFile[0].file.size})
        .success(function(data){
            console.log("file uploded successfully.");
        });*/
        $http({method : 'POST',url : 'rest/uploadFiles',  headers : {'Content-Type' : false},transformRequest : function(data) {
            var formData = new FormData();
            //formData.append("model", angular.toJson(data.model));
            for (var i = 0; i < data.files.length; i++) {
                console.log(i+"th file uploading");
                formData.append("file" + i, data.files[i].file);
            }
            console.log("formdata,",formData)
            return formData;
        },
        data : {files : $scope.uploadedFile}
        }).success(function(data){
            console.log(data);
            console.log("file uploaded successfully");
        }).error(function(data){
            console.log(data);
            console.log("error occured while uploading file");
        });
    };
    
    $scope.uploadFile = function(){
        var file = $scope.myFile;
        console.log('file is ' );
        console.dir(file);
        var uploadUrl = "rest/uploadFiles";
        var response=fileUpload.uploadFileToUrl($scope.myFile, uploadUrl);
        console.log("file upload called");
        response.success(function(data){
            console.log(data);
            $scope.contactList=data;
            console.log("file uploaded successfully");
        }).error(function(data){
            console.log(data);
            console.log("error occured while uploading file");            
        });
    };
    $scope.getContactList=function(){
        console.log("get contact called");
        $http.post('rest/getContactList').error(function(data,status){
            
        }).success(function(data,status){
            $scope.contactList=data;
            console.log("size of feched list: "+data.length);
        });
    }
    $scope.validateSalutation=function(input,index){
        console.log("user input:",input);
        if(input!=null && input!="" && input!=undefined){
            console.log("valid salutation");
            $scope.contactList[index].salutation.errorPresent=false;
        }else{
            console.log("Invalid salutation");
            $scope.contactList[index].salutation.errorPresent=true;
            $scope.contactList[index].salutation.errorMsg="Mandatory field";
        }
    };
    $scope.saveContactList=[];
    $scope.selectContactCheckbox=function(index){
        console.log("checked contact:",index);
        $scope.saveContactList.push($scope.contactList[index]);
        console.log("size after adding:"+$scope.saveContactList.length);
    };
    $scope.deselectContactCheckbox=function(){
        
    };
    $scope.saveContact=function(){
        
    }
    $scope.download=function(){
        
    };
};
app.controller("uploadDownloadController",uploadDownloadController);