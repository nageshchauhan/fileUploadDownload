package com.fileuploaddownload.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.fileuploaddownload.dto.Contact;
import com.fileuploaddownload.dto.ExcelParam;
import com.fileuploaddownload.processing.ExcelProcessing;

@Controller
public class FileUploadDownloadController {
    
    @RequestMapping(value = "/uploadFiles", method = RequestMethod.POST ,produces = "application/json")
    @ResponseBody
    public List<Contact> fileUpload(MultipartHttpServletRequest request, HttpServletRequest req) {
        List<Contact> contactList=new ArrayList<Contact>();
        try{
            System.out.println("File upload called");
/*            ObjectMapper mapper=new ObjectMapper();

            Map<String,Object> data=mapper.readValue(str, Map.class);
            System.out.println("File name: "+data.get("filename"));
            Map<Object,Object> lm=(Map<Object,Object>)data.get("file");*/
            
            Iterator<String> itr=request.getFileNames();
            System.out.println("itr,"+itr.hasNext());
            MultipartFile file1=request.getFile(itr.next());
            if(file1!=null){
                String fileName=file1.getOriginalFilename();
                System.out.println("uploaded file name : "+fileName);
            }
            Contact contact1=new Contact();
            ExcelParam firstName=new ExcelParam();
            firstName.setKey("first name");
            firstName.setErrorPresent(false);
            firstName.setValue("Nagesh");
            contact1.setFirstName(firstName);
            contactList.add(contact1);
        }catch(Exception e){
            e.printStackTrace();
        }
        return contactList;
    }
    
    @RequestMapping(value = "/getContactList", method = RequestMethod.POST ,produces = "application/json")
    @ResponseBody
    public List<Contact> getContactList(HttpServletRequest req) {
        return readExcelAndValidate();
    } 
    
    private List<Contact> readExcelAndValidate(){
        List<Contact> contactList=new ArrayList<Contact>();
        ExcelProcessing processing = new ExcelProcessing();
        Contact contact1=new Contact();
        contact1.setSalutation(processing.getSalutation(null));
        contact1.setFirstName(processing.getFirstName("Nagesh"));
        contact1.setLastName(processing.getLastName(null));
        contact1.setEmailId(processing.getEmailId("Nagesh"));
        contactList.add(contact1);
        
        Contact contact2=new Contact();
        contact2.setFirstName(processing.getFirstName(null));
        contact2.setLastName(processing.getLastName("Testing"));
        contact2.setSalutation(processing.getSalutation("Mr."));
        contact2.setPhoneNum(processing.getPhoneNum(null));
        contactList.add(contact2);
        return contactList;
    }
}
