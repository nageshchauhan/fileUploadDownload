package com.fileuploaddownload.dto;

public class ExcelParam {
    private String key;
    private Object value;
    private boolean isErrorPresent;
    private String errorMsg;
    public String getKey() {
        return key;
    }
    public void setKey(String key) {
        this.key = key;
    }
    
    public Object getValue() {
        return value;
    }
    public void setValue(Object value) {
        this.value = value;
    }
    public boolean isErrorPresent() {
        return isErrorPresent;
    }
    public void setErrorPresent(boolean isErrorPresent) {
        this.isErrorPresent = isErrorPresent;
    }
    public String getErrorMsg() {
        return errorMsg;
    }
    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }
    
}
