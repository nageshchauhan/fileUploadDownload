package com.fileuploaddownload.dto;

public class Contact {
    private ExcelParam salutation;
    private ExcelParam firstName;
    private ExcelParam lastName;
    private ExcelParam emailId;
    private ExcelParam phoneNum;

    public ExcelParam getSalutation() {
        return salutation;
    }

    public void setSalutation(ExcelParam salutation) {
        this.salutation = salutation;
    }

    public ExcelParam getFirstName() {
        return firstName;
    }

    public void setFirstName(ExcelParam firstName) {
        this.firstName = firstName;
    }
    
    public ExcelParam getLastName() {
        return lastName;
    }

    public void setLastName(ExcelParam lastName) {
        this.lastName = lastName;
    }

    public ExcelParam getEmailId() {
        return emailId;
    }

    public void setEmailId(ExcelParam emailId) {
        this.emailId = emailId;
    }

    public ExcelParam getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(ExcelParam phoneNum) {
        this.phoneNum = phoneNum;
    }
    
}
