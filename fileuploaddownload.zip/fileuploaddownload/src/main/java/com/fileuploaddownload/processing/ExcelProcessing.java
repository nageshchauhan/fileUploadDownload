package com.fileuploaddownload.processing;

import com.fileuploaddownload.dto.ExcelParam;

public class ExcelProcessing {
    
    public ExcelParam getSalutation(String strName){
        ExcelParam salutation=new ExcelParam();
        if(strName==null){
            salutation.setErrorPresent(true);
            salutation.setErrorMsg("Invalid salutation");
        }
        salutation.setKey("Salutation");
        salutation.setValue(strName);
        return salutation;
    }
    public ExcelParam getFirstName(String strName){
        ExcelParam firstName=new ExcelParam();
        if(strName==null){
            firstName.setErrorPresent(true);
            firstName.setErrorMsg("First name is mandatory");
        }
        firstName.setKey("first name");
        firstName.setValue(strName);
        return firstName;
    }
    public ExcelParam getLastName(String strName){
        ExcelParam lastName=new ExcelParam();
        if(strName==null){
            lastName.setErrorPresent(true);
            lastName.setErrorMsg("Last name is mandatory");
        }
        lastName.setKey("last name");
        lastName.setValue(strName);
        return lastName;
    }
    public ExcelParam getEmailId(String str){
        ExcelParam emailId=new ExcelParam();
        if(str==null){
            emailId.setErrorPresent(true);
            emailId.setErrorMsg("Email id is mandatory");
        }
        emailId.setKey("Email id");
        emailId.setValue(str);
        return emailId;
    }
    public ExcelParam getPhoneNum(String str){
        ExcelParam phoneNum=new ExcelParam();
        if(str==null){
            phoneNum.setErrorPresent(true);
            phoneNum.setErrorMsg("Invalid phone number");
        }
        phoneNum.setKey("Phone number");
        phoneNum.setValue(str);
        return phoneNum;
    }
}
