package com.fileuploaddownload.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class FileUploadDownloadController {
    
    @RequestMapping(value = "/uploadFiles", method = RequestMethod.POST ,produces = "application/json")
    @ResponseBody
    public String fileUpload(@RequestBody String str, HttpServletRequest req) {
        try{
            System.out.println("File upload called");
            ObjectMapper mapper=new ObjectMapper();

            Map<String,Object> data=mapper.readValue(str, Map.class);
            System.out.println("File name: "+data.get("filename"));
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }

}
