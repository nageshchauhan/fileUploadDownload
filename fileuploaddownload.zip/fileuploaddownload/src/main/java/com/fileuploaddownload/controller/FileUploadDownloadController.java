package com.fileuploaddownload.controller;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.fileuploaddownload.dto.Contact;
import com.fileuploaddownload.dto.ExcelParam;
import com.fileuploaddownload.processing.ExcelProcessing;

@Controller
public class FileUploadDownloadController {
    
    @RequestMapping(value = "/uploadFiles", method = RequestMethod.POST ,produces = "application/json")
    @ResponseBody
    public List<Contact> fileUpload(MultipartHttpServletRequest request, HttpServletRequest req) {
        List<Contact> contactList=new ArrayList<Contact>();
        try{
            System.out.println("File upload called");
            
            MultipartFile file=request.getFile("file");
            System.out.println("file name:"+file.getOriginalFilename());
            
            
            InputStream is=file.getInputStream();
            
            System.out.println("Reading file");
            
            //Workbook workbook=new HSSFWorkbook(is);
            Workbook workbook=WorkbookFactory.create(is);
            Sheet sheet=workbook.getSheetAt(0);
            System.out.println("File read successfully");
            
            String []correctRowNames={"FirstName","LastName","EmailId"};
            int rowsCount = sheet.getLastRowNum();
            System.out.println("Total Number of Rows: " + (rowsCount + 1));
            if(rowsCount==0){
                System.out.println("Blank excel file uploaded");
            }
            if(rowsCount<1){
                System.out.println("Excel file with one row (i.e. only Header)");
            }
            String []givenColumns = null;
            for (int i = 0; i <= 0; i++) {
                Row row = sheet.getRow(i);
                int colCounts = row.getLastCellNum();
                givenColumns=new String[colCounts];
                System.out.println("Total Number of Cols: " + colCounts);
                for (int j = 0; j < colCounts; j++) {
                    Cell cell = row.getCell(j);
                    givenColumns[j]=cell.getStringCellValue();
                    System.out.println("[" + i + "," + j + "]=" + cell.getStringCellValue());
                }
            }
            compareColumnList(givenColumns, correctRowNames);
            Contact contact1=new Contact();
            ExcelParam firstName=new ExcelParam();
            firstName.setKey("first name");
            firstName.setErrorPresent(false);
            firstName.setValue("Nagesh");
            contact1.setFirstName(firstName);
            contactList.add(contact1);
        }catch(Exception e){
            e.printStackTrace();
        }
        return contactList;
    }
    
    private void compareColumnList(String[] actual,String[] expected){
        System.out.println("Actual list ");
        for(int i=0;i<actual.length;i++){
            String key=actual[i];
            Pattern pt = Pattern.compile("[^a-zA-Z0-9]");
            Matcher match= pt.matcher(key);
            while(match.find())
            {
                String s= match.group();
                key=key.replaceAll("\\"+s, "");
            }
            System.out.print(key+",");
        }
        System.out.println();
        System.out.println("Expected list");
        for(int i=0;i<expected.length;i++){
            System.out.print(expected[i]+",");
        }
        System.out.println();
    }
    
    @RequestMapping(value = "/getContactList", method = RequestMethod.POST ,produces = "application/json")
    @ResponseBody
    public List<Contact> getContactList(HttpServletRequest req) {
        return readExcelAndValidate();
    } 
    
    private List<Contact> readExcelAndValidate(){
        List<Contact> contactList=new ArrayList<Contact>();
        ExcelProcessing processing = new ExcelProcessing();
        Contact contact1=new Contact();
        contact1.setSalutation(processing.getSalutation(null));
        contact1.setFirstName(processing.getFirstName("Nagesh"));
        contact1.setLastName(processing.getLastName(null));
        contact1.setEmailId(processing.getEmailId("Nagesh"));
        contactList.add(contact1);
        
        Contact contact2=new Contact();
        contact2.setFirstName(processing.getFirstName(null));
        contact2.setLastName(processing.getLastName("Testing"));
        contact2.setSalutation(processing.getSalutation("Mr."));
        contact2.setPhoneNum(processing.getPhoneNum(null));
        contactList.add(contact2);
        return contactList;
    }
}
