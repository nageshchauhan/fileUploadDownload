/**
 * 
 */

var app=angular.module("fileUploadDownloadApp",['angularFileUpload']);

var uploadDownloadController=function($scope,$upload,$http){
    
    $scope.selectFile=function($files){
        console.log("file selected : ",$files);
        $scope.uploadedFile = [ {file : ''} ];
        if($files.length>0){
            $scope.uploadedFile[0].file=$files[0];
        }
    };
    $scope.upload=function(){
        console.log("upload function called");
        var fileName=$scope.uploadedFile[0].file.name;
        console.log("step 1:",fileName);
        
        $http.post('rest/uploadFiles', 
                {filename: $scope.uploadedFile[0].file.name,
                file:$scope.uploadedFile[0].file,
                fileSize:$scope.uploadedFile[0].file.size})
        .success(function(data){
            console.log("file uploded successfully.");
        });
    };
    $scope.download=function(){
        
    };
};
app.controller("uploadDownloadController",uploadDownloadController);